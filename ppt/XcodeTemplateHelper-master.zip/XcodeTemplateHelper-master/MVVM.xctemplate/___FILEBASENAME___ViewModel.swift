//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import RxCocoa
import RxSwift

protocol ___VARIABLE_MVVMModuleName___ViewModelType: ViewModelType {
  // Input
  
  // Output
  
}

// MARK: - Class Implementation

struct ___VARIABLE_MVVMModuleName___ViewModel: ___VARIABLE_MVVMModuleName___ViewModelType {
  
  // MARK: Properties
  
  let disposeBag = DisposeBag()
  
  // Input
  
  // Output
  
  // MARK: Initializing
  
  init() {
    
  }
}
