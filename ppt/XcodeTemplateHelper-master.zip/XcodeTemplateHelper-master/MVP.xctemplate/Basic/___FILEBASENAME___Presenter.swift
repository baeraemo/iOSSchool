//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol ___VARIABLE_MVPModuleName___PresenterType: class, PresenterType {
  weak var view: ___VARIABLE_MVPModuleName___ViewType! { get set }
//  <#Protocols#>
}

// MARK: - Class Implementation

final class ___VARIABLE_MVPModuleName___Presenter {
  
  // MARK: Properties
  
  weak var view: ___VARIABLE_MVPModuleName___ViewType!
//  <#Properties#>
  
  // MARK: Initializing
  
  init() {
//  <#Init#>
  }
  
  // MARK: Life Cycle
  
  func onViewDidLoad() {
    
  }
  
  // MARK:
  
}

// MARK: - ___VARIABLE_MVPModuleName___PresenterType

extension ___VARIABLE_MVPModuleName___Presenter: ___VARIABLE_MVPModuleName___PresenterType {
//  <#Code#>
}
